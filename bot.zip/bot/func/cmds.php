<?php
if ((strpos($message, "/cmds") === 0)||(strpos($message, "!cmds") === 0)||(strpos($message, ".cmds") === 0))
{
  sendChatAction($chatId,"type");
  $cmd = urlencode("
⌬ 𝗖𝗖 𝗖𝗛𝗘𝗖𝗞𝗘𝗥 𝗚𝗔𝗧𝗘𝗦 

➥ /ch - Stripe Charge $1
➥ /chk - Braintree Auth
➥ /sk - Check Your SK
➥ /sho - Shopify + b3 10$ 
➥ /vbv - B3 VBV
➥ /sq - Square Charge 0.1$
➥ /gg - Google Play
⌬ 𝗨𝗦𝗘𝗥 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦

𝗕𝗢𝗧 𝗕𝗬 - $bowner
");
  reply_to($chatId,$cmd,$messageId);
}

?>