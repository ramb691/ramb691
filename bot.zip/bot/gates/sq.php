<?php
if($message == "/sq ".str_replace("/sq ","",$message) or $message == "!sq ".str_replace("!sq ","",$message) or $message == ".sq ".str_replace(".sq ","",$message)){

$upd = urlencode("
➜ 𝘾𝙃𝙀𝘾𝙆𝙄𝙉𝙂 𝙎𝙏𝘼𝙍𝙏𝙀𝘿...
");
$sss = reply_to($chatId,$upd,$messageId);
$respon = json_decode($sss, 1);
$message_id_1 = $respon['result']['message_id'];


$ccs  = getCards($message);
if(empty($ccs)){
 $upd = urlencode("
𝗖𝗖 𝗡𝗢𝗧 𝗙𝗢𝗨𝗡𝗗 ❌...
");
edit_message($chatId,"$upd ",$message_id_1); 
return;
}
$cc = $ccs[0];
$mes = $ccs[1];
$ano = $ccs[2];
$cvv = $ccs[3];
$card= "$ccs[0]|$ccs[1]|$ccs[2]|$ccs[3]";
$upd = urlencode("
𝙒𝘼𝙄𝙏𝙄𝙉𝙂 𝙁𝙊𝙍 𝙍𝙀𝙎𝙐𝙇𝙏𝙎...
");
edit_message($chatId,"$upd ",$message_id_1); 

$ch = curl_init("https://".$_SERVER['SERVER_NAME']."/api/square.php?lista=".$card);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$result1= curl_exec($ch);
$result = json_decode($result1,1);

$status = $result["status"];
$check = $result["check"];
$proxy = $result["proxy"];
$emoji = $result["emoji"];
$msg = $result["result"];
$gate = $result["gate"];
$bin = $result["bin"];
$bank = $result["bank"];
$country = $result["country"];
$type = $result["type"];
$brand = $result["brand"];
$flag = $result["flag"];


$res  = urlencode("
『 $gate 』
⌬ ᴄᴀʀᴅ : <code>$card</code>
⌬ sᴛᴀᴛᴜs $check $emoji
⌬ ʀᴇsᴘᴏɴsᴇ : <b>$msg</b> 

『 ʙɪɴ ɪɴғᴏ 』
∆ 𝘽𝙄𝙉: $bin - $brand
∆ 𝘽𝘼𝙉𝙆: $bank
∆ 𝘾𝙊𝙐𝙉𝙏𝙍𝙔: $country $flag
∆ 𝙏𝙔𝙋𝙀: $type

ᴄʜᴇᴄᴋᴇᴅ ʙʏ : $user
『 𝗕𝗢𝗧 𝗕𝗬 - $bowner 』
");

  
edit_message($chatId,$res,$message_id_1);

}