<?php
error_reporting(0);

$bin = substr($cc, 0, 6);
$api_bin = json_decode(file_get_contents("https://lookup.binlist.net/".$bin),1);

$scheme = strtoupper($api_bin["scheme"]) ?? "Unknow";
$type = strtoupper($api_bin["type"]) ?? "Unknow";
$brand = strtoupper($api_bin["brand"]) ?? "Unknow";
$country = strtoupper($api_bin["country"]["name"]) ?? "Unknow";
$flag = $api_bin["country"]["emoji"] ?? "Unknow";
$bank = strtoupper($api_bin["bank"]["name"]) ?? "Unknow";
$ccode = strtoupper($api_bin["country"]["alpha2"]) ?? "Unknow";
if(!$ccode or !isset($ccode)){
$api_bin = json_decode(file_get_contents("https://api.dlyar-dev.tk/info-bin?bin=".$bin),1);

$scheme = $api_bin["scheme"] ?? "Unknow";
$type = $api_bin["type"] ?? "Unknow";
$brand = $api_bin["brand"] ?? "Unknow";
$country = $api_bin["country"] ?? "Unknow";
$flag = $api_bin["flag"] ?? "Unknow";
$bank = $api_bin["bank"] ?? "Unknow";
$ccode = $api_bin["ccode"] ?? "Unknow";
}
if($country == "UNITED STATES OF AMERICA"){
$country = "UNITED STATES";
}elseif($country == "UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND") {
$country = "UNITED KINGDOM";
}