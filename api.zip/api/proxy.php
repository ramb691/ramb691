<?php
$p = file_get_contents("proxy.txt");
$ex = explode("\n",$p);
$rand = array_rand($ex);
$proxy = $ex[$rand];


$ex = explode(":", str_replace("@",":",$proxy));
define("host",$ex[0]);
define("port",$ex[1]);
define("user",$ex[2]);
define("pass",$ex[3]);


